﻿namespace PVSMediaPlayerHowTo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        ///// <summary>
        ///// Clean up any resources being used.
        ///// </summary>
        ///// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing && (components != null))
        //    {
        //        components.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.caption1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.caption3 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.caption6 = new System.Windows.Forms.Label();
            this.caption7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.caption2 = new System.Windows.Forms.Label();
            this.caption4 = new System.Windows.Forms.Label();
            this.caption5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.caption8 = new System.Windows.Forms.Label();
            this.caption9 = new System.Windows.Forms.Label();
            this.caption10 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.caption11 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.caption12 = new System.Windows.Forms.Label();
            this.caption13 = new System.Windows.Forms.Label();
            this.caption14 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.caption15 = new System.Windows.Forms.Label();
            this.caption16 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.taskbarBox = new System.Windows.Forms.CheckBox();
            this.button4 = new PVSMediaPlayerHowTo.CustomButton();
            this.button3 = new PVSMediaPlayerHowTo.CustomButton();
            this.button2 = new PVSMediaPlayerHowTo.CustomButton();
            this.button1 = new PVSMediaPlayerHowTo.CustomButton();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // caption1
            // 
            this.caption1.AutoSize = true;
            this.caption1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.caption1.Location = new System.Drawing.Point(16, 28);
            this.caption1.Name = "caption1";
            this.caption1.Size = new System.Drawing.Size(289, 16);
            this.caption1.TabIndex = 0;
            this.caption1.Text = "This panel is used as the player\'s main display:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(19, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 181);
            this.panel1.TabIndex = 1;
            // 
            // caption3
            // 
            this.caption3.AutoSize = true;
            this.caption3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption3.Location = new System.Drawing.Point(16, 233);
            this.caption3.Name = "caption3";
            this.caption3.Size = new System.Drawing.Size(55, 16);
            this.caption3.TabIndex = 5;
            this.caption3.Text = "\'panel1\'";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(19, 62);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(305, 45);
            this.trackBar1.TabIndex = 1;
            this.trackBar1.TickFrequency = 10000;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.Both;
            // 
            // caption6
            // 
            this.caption6.AutoSize = true;
            this.caption6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.caption6.Location = new System.Drawing.Point(16, 28);
            this.caption6.Name = "caption6";
            this.caption6.Size = new System.Drawing.Size(308, 32);
            this.caption6.TabIndex = 0;
            this.caption6.Text = "This trackbar is used as the player\'s position slider\r\nand is controlled by the p" +
    "layer:";
            // 
            // caption7
            // 
            this.caption7.AutoSize = true;
            this.caption7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption7.Location = new System.Drawing.Point(16, 105);
            this.caption7.Name = "caption7";
            this.caption7.Size = new System.Drawing.Size(71, 16);
            this.caption7.TabIndex = 2;
            this.caption7.Text = "\'trackBar1\'";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(343, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(150, 181);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(499, 47);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(150, 181);
            this.panel3.TabIndex = 4;
            // 
            // caption2
            // 
            this.caption2.AutoSize = true;
            this.caption2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.caption2.Location = new System.Drawing.Point(340, 28);
            this.caption2.Name = "caption2";
            this.caption2.Size = new System.Drawing.Size(268, 16);
            this.caption2.TabIndex = 2;
            this.caption2.Text = "These 2 panels are used as display clones:";
            // 
            // caption4
            // 
            this.caption4.AutoSize = true;
            this.caption4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption4.Location = new System.Drawing.Point(340, 233);
            this.caption4.Name = "caption4";
            this.caption4.Size = new System.Drawing.Size(55, 16);
            this.caption4.TabIndex = 7;
            this.caption4.Text = "\'panel2\'";
            // 
            // caption5
            // 
            this.caption5.AutoSize = true;
            this.caption5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption5.Location = new System.Drawing.Point(599, 233);
            this.caption5.Name = "caption5";
            this.caption5.Size = new System.Drawing.Size(55, 16);
            this.caption5.TabIndex = 9;
            this.caption5.Text = "\'panel3\'";
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label1.Location = new System.Drawing.Point(43, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "00:00:00";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label2.Location = new System.Drawing.Point(204, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "00:00:00";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // caption8
            // 
            this.caption8.AutoSize = true;
            this.caption8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.caption8.Location = new System.Drawing.Point(16, 28);
            this.caption8.Name = "caption8";
            this.caption8.Size = new System.Drawing.Size(292, 32);
            this.caption8.TabIndex = 0;
            this.caption8.Text = "These 2 labels show the playback position time:\r\nfrom the beginning:             " +
    "           and to the end:";
            // 
            // caption9
            // 
            this.caption9.AutoSize = true;
            this.caption9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption9.Location = new System.Drawing.Point(40, 105);
            this.caption9.Name = "caption9";
            this.caption9.Size = new System.Drawing.Size(51, 16);
            this.caption9.TabIndex = 3;
            this.caption9.Text = "\'label1\'";
            // 
            // caption10
            // 
            this.caption10.AutoSize = true;
            this.caption10.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption10.Location = new System.Drawing.Point(202, 105);
            this.caption10.Name = "caption10";
            this.caption10.Size = new System.Drawing.Size(51, 16);
            this.caption10.TabIndex = 4;
            this.caption10.Text = "\'label2\'";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.checkBox1.Location = new System.Drawing.Point(124, 232);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(110, 20);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Show Overlay";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.checkBox2.Location = new System.Drawing.Point(444, 232);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(110, 20);
            this.checkBox2.TabIndex = 8;
            this.checkBox2.Text = "Show Overlay";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.CheckBox2_CheckedChanged);
            // 
            // caption11
            // 
            this.caption11.AutoSize = true;
            this.caption11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.caption11.Location = new System.Drawing.Point(16, 28);
            this.caption11.Name = "caption11";
            this.caption11.Size = new System.Drawing.Size(296, 32);
            this.caption11.TabIndex = 0;
            this.caption11.Text = "And these audio volume and balance sliders are\r\nalso controlled by the player:";
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(19, 62);
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(145, 45);
            this.trackBar2.TabIndex = 1;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar2.Value = 10;
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(179, 62);
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(145, 45);
            this.trackBar3.TabIndex = 2;
            this.trackBar3.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar3.Value = 5;
            // 
            // caption12
            // 
            this.caption12.AutoSize = true;
            this.caption12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption12.Location = new System.Drawing.Point(16, 105);
            this.caption12.Name = "caption12";
            this.caption12.Size = new System.Drawing.Size(71, 16);
            this.caption12.TabIndex = 3;
            this.caption12.Text = "\'trackBar2\'";
            // 
            // caption13
            // 
            this.caption13.AutoSize = true;
            this.caption13.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption13.Location = new System.Drawing.Point(176, 105);
            this.caption13.Name = "caption13";
            this.caption13.Size = new System.Drawing.Size(71, 16);
            this.caption13.TabIndex = 5;
            this.caption13.Text = "\'trackBar3\'";
            // 
            // caption14
            // 
            this.caption14.AutoSize = true;
            this.caption14.Location = new System.Drawing.Point(16, 28);
            this.caption14.Name = "caption14";
            this.caption14.Size = new System.Drawing.Size(294, 32);
            this.caption14.TabIndex = 0;
            this.caption14.Text = "These 2 panels show media audio output levels:\r\nleft channel (or mono):      and " +
    "right channel:";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(19, 78);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(140, 12);
            this.panel4.TabIndex = 1;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel4_Paint);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Location = new System.Drawing.Point(166, 78);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(140, 12);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel5_Paint);
            // 
            // caption15
            // 
            this.caption15.AutoSize = true;
            this.caption15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption15.Location = new System.Drawing.Point(16, 105);
            this.caption15.Name = "caption15";
            this.caption15.Size = new System.Drawing.Size(55, 16);
            this.caption15.TabIndex = 3;
            this.caption15.Text = "\'panel4\'";
            // 
            // caption16
            // 
            this.caption16.AutoSize = true;
            this.caption16.ForeColor = System.Drawing.SystemColors.GrayText;
            this.caption16.Location = new System.Drawing.Point(164, 105);
            this.caption16.Name = "caption16";
            this.caption16.Size = new System.Drawing.Size(55, 16);
            this.caption16.TabIndex = 5;
            this.caption16.Text = "\'panel5\'";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.caption1);
            this.groupBox1.Controls.Add(this.caption3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.caption2);
            this.groupBox1.Controls.Add(this.caption4);
            this.groupBox1.Controls.Add(this.caption5);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(669, 259);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.checkBox4.Location = new System.Drawing.Point(271, 232);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(67, 20);
            this.checkBox4.TabIndex = 10;
            this.checkBox4.Text = "Shape";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.CheckBox4_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.caption6);
            this.groupBox2.Controls.Add(this.trackBar1);
            this.groupBox2.Controls.Add(this.caption7);
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.groupBox2.Location = new System.Drawing.Point(13, 277);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(336, 132);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Position Slider";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.checkBox3.Location = new System.Drawing.Point(174, 104);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(151, 20);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Position Live Update";
            this.checkBox3.UseVisualStyleBackColor = false;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.CheckBox3_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.caption8);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.caption9);
            this.groupBox3.Controls.Add(this.caption10);
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.groupBox3.Location = new System.Drawing.Point(355, 277);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(326, 132);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Playback Position";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.caption14);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.panel5);
            this.groupBox4.Controls.Add(this.caption15);
            this.groupBox4.Controls.Add(this.caption16);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.groupBox4.Location = new System.Drawing.Point(355, 416);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(326, 132);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Audio Output Level";
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label6.Location = new System.Drawing.Point(256, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 18);
            this.label6.TabIndex = 6;
            this.label6.Text = "0.00";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label5.Location = new System.Drawing.Point(108, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "0.00";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.caption11);
            this.groupBox5.Controls.Add(this.caption13);
            this.groupBox5.Controls.Add(this.caption12);
            this.groupBox5.Controls.Add(this.trackBar3);
            this.groupBox5.Controls.Add(this.trackBar2);
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.groupBox5.Location = new System.Drawing.Point(12, 416);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(336, 132);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Audio Sliders";
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label4.Location = new System.Drawing.Point(266, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "0.00";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.label3.Location = new System.Drawing.Point(106, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "1.00";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // taskbarBox
            // 
            this.taskbarBox.AutoSize = true;
            this.taskbarBox.Checked = true;
            this.taskbarBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.taskbarBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.taskbarBox.Location = new System.Drawing.Point(345, 566);
            this.taskbarBox.Name = "taskbarBox";
            this.taskbarBox.Size = new System.Drawing.Size(226, 20);
            this.taskbarBox.TabIndex = 9;
            this.taskbarBox.Text = "Show Taskbar Progress Indicator";
            this.taskbarBox.UseVisualStyleBackColor = true;
            this.taskbarBox.CheckedChanged += new System.EventHandler(this.TaskbarBox_CheckedChanged);
            // 
            // button4
            // 
            this.button4.BorderColor = System.Drawing.Color.Gray;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.button4.Location = new System.Drawing.Point(582, 563);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 25);
            this.button4.TabIndex = 13;
            this.button4.Text = "Quit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button5_Click);
            // 
            // button3
            // 
            this.button3.BorderColor = System.Drawing.Color.Gray;
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.button3.Location = new System.Drawing.Point(225, 563);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 25);
            this.button3.TabIndex = 12;
            this.button3.Text = "Stop";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // button2
            // 
            this.button2.BorderColor = System.Drawing.Color.Gray;
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.button2.Location = new System.Drawing.Point(118, 563);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 25);
            this.button2.TabIndex = 11;
            this.button2.Text = "Pause";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button1
            // 
            this.button1.BorderColor = System.Drawing.Color.Gray;
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(173)))), ((int)(((byte)(146)))));
            this.button1.Location = new System.Drawing.Point(11, 563);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 10;
            this.button1.Text = "Play";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(693, 601);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.taskbarBox);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.GrayText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PVS.MediaPlayer How To... (C#)";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label caption1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label caption3;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label caption6;
        private System.Windows.Forms.Label caption7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label caption2;
        private System.Windows.Forms.Label caption4;
        private System.Windows.Forms.Label caption5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label caption8;
        private System.Windows.Forms.Label caption9;
        private System.Windows.Forms.Label caption10;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label caption11;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.Label caption12;
        private System.Windows.Forms.Label caption13;
        private System.Windows.Forms.Label caption14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label caption15;
        private System.Windows.Forms.Label caption16;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox taskbarBox;
        private System.Windows.Forms.CheckBox checkBox4;
        private CustomButton button1;
        private CustomButton button2;
        private CustomButton button3;
        private CustomButton button4;
    }
}

