﻿Imports System.Windows.Forms

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    ''Form overrides dispose to clean up the component list.
    '<System.Diagnostics.DebuggerNonUserCode()> _
    'Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    '    Try
    '        If disposing AndAlso components IsNot Nothing Then
    '            components.Dispose()
    '        End If
    '    Finally
    '        MyBase.Dispose(disposing)
    '    End Try
    'End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Caption1 = New System.Windows.Forms.Label()
        Me.Caption2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Caption3 = New System.Windows.Forms.Label()
        Me.Caption4 = New System.Windows.Forms.Label()
        Me.Caption5 = New System.Windows.Forms.Label()
        Me.Caption6 = New System.Windows.Forms.Label()
        Me.Caption8 = New System.Windows.Forms.Label()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Caption7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Caption9 = New System.Windows.Forms.Label()
        Me.Caption10 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Caption11 = New System.Windows.Forms.Label()
        Me.Caption14 = New System.Windows.Forms.Label()
        Me.TrackBar2 = New System.Windows.Forms.TrackBar()
        Me.TrackBar3 = New System.Windows.Forms.TrackBar()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Caption13 = New System.Windows.Forms.Label()
        Me.Caption12 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Caption16 = New System.Windows.Forms.Label()
        Me.Caption15 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TaskbarBox = New System.Windows.Forms.CheckBox()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Caption1
        '
        Me.Caption1.AutoSize = True
        Me.Caption1.Location = New System.Drawing.Point(16, 28)
        Me.Caption1.Name = "Caption1"
        Me.Caption1.Size = New System.Drawing.Size(289, 16)
        Me.Caption1.TabIndex = 0
        Me.Caption1.Text = "This panel is used as the player's main display:"
        '
        'Caption2
        '
        Me.Caption2.AutoSize = True
        Me.Caption2.Location = New System.Drawing.Point(340, 28)
        Me.Caption2.Name = "Caption2"
        Me.Caption2.Size = New System.Drawing.Size(268, 16)
        Me.Caption2.TabIndex = 2
        Me.Caption2.Text = "These 2 panels are used as display clones:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Location = New System.Drawing.Point(19, 47)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(317, 181)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Location = New System.Drawing.Point(343, 47)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(150, 181)
        Me.Panel2.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Location = New System.Drawing.Point(499, 47)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(150, 181)
        Me.Panel3.TabIndex = 4
        '
        'Caption3
        '
        Me.Caption3.AutoSize = True
        Me.Caption3.ForeColor = System.Drawing.Color.DimGray
        Me.Caption3.Location = New System.Drawing.Point(16, 231)
        Me.Caption3.Name = "Caption3"
        Me.Caption3.Size = New System.Drawing.Size(56, 16)
        Me.Caption3.TabIndex = 5
        Me.Caption3.Text = "'Panel1'"
        '
        'Caption4
        '
        Me.Caption4.AutoSize = True
        Me.Caption4.ForeColor = System.Drawing.Color.DimGray
        Me.Caption4.Location = New System.Drawing.Point(340, 231)
        Me.Caption4.Name = "Caption4"
        Me.Caption4.Size = New System.Drawing.Size(56, 16)
        Me.Caption4.TabIndex = 7
        Me.Caption4.Text = "'Panel2'"
        '
        'Caption5
        '
        Me.Caption5.AutoSize = True
        Me.Caption5.ForeColor = System.Drawing.Color.DimGray
        Me.Caption5.Location = New System.Drawing.Point(598, 231)
        Me.Caption5.Name = "Caption5"
        Me.Caption5.Size = New System.Drawing.Size(56, 16)
        Me.Caption5.TabIndex = 9
        Me.Caption5.Text = "'Panel3'"
        '
        'Caption6
        '
        Me.Caption6.AutoSize = True
        Me.Caption6.Location = New System.Drawing.Point(16, 28)
        Me.Caption6.Name = "Caption6"
        Me.Caption6.Size = New System.Drawing.Size(308, 32)
        Me.Caption6.TabIndex = 0
        Me.Caption6.Text = "This trackbar is used as the player's position slider" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and is controlled by the p" &
    "layer:"
        '
        'Caption8
        '
        Me.Caption8.AutoSize = True
        Me.Caption8.Location = New System.Drawing.Point(16, 28)
        Me.Caption8.Name = "Caption8"
        Me.Caption8.Size = New System.Drawing.Size(292, 32)
        Me.Caption8.TabIndex = 0
        Me.Caption8.Text = "These 2 labels show the playback position time:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "from the beginning:             " &
    "           and to the end:"
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(19, 62)
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(305, 45)
        Me.TrackBar1.TabIndex = 1
        Me.TrackBar1.TickFrequency = 10000
        Me.TrackBar1.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Caption7
        '
        Me.Caption7.AutoSize = True
        Me.Caption7.ForeColor = System.Drawing.Color.DimGray
        Me.Caption7.Location = New System.Drawing.Point(16, 105)
        Me.Caption7.Name = "Caption7"
        Me.Caption7.Size = New System.Drawing.Size(77, 16)
        Me.Caption7.TabIndex = 2
        Me.Caption7.Text = "'TrackBar1'"
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(43, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 22)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "00:00:00"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(204, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 22)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "00:00:00"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Caption9
        '
        Me.Caption9.AutoSize = True
        Me.Caption9.ForeColor = System.Drawing.Color.DimGray
        Me.Caption9.Location = New System.Drawing.Point(40, 105)
        Me.Caption9.Name = "Caption9"
        Me.Caption9.Size = New System.Drawing.Size(55, 16)
        Me.Caption9.TabIndex = 3
        Me.Caption9.Text = "'Label1'"
        '
        'Caption10
        '
        Me.Caption10.AutoSize = True
        Me.Caption10.ForeColor = System.Drawing.Color.DimGray
        Me.Caption10.Location = New System.Drawing.Point(202, 105)
        Me.Caption10.Name = "Caption10"
        Me.Caption10.Size = New System.Drawing.Size(55, 16)
        Me.Caption10.TabIndex = 4
        Me.Caption10.Text = "'Label2'"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(124, 230)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(110, 20)
        Me.CheckBox1.TabIndex = 6
        Me.CheckBox1.Text = "Show Overlay"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.Location = New System.Drawing.Point(444, 230)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(110, 20)
        Me.CheckBox2.TabIndex = 8
        Me.CheckBox2.Text = "Show Overlay"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Caption11
        '
        Me.Caption11.AutoSize = True
        Me.Caption11.Location = New System.Drawing.Point(16, 28)
        Me.Caption11.Name = "Caption11"
        Me.Caption11.Size = New System.Drawing.Size(296, 32)
        Me.Caption11.TabIndex = 0
        Me.Caption11.Text = "And these audio volume and balance sliders are" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "also controlled by the player:"
        '
        'Caption14
        '
        Me.Caption14.AutoSize = True
        Me.Caption14.Location = New System.Drawing.Point(16, 28)
        Me.Caption14.Name = "Caption14"
        Me.Caption14.Size = New System.Drawing.Size(294, 32)
        Me.Caption14.TabIndex = 0
        Me.Caption14.Text = "These 2 panels show media audio output levels:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "left channel (or mono):      and " &
    "right channel:"
        '
        'TrackBar2
        '
        Me.TrackBar2.Location = New System.Drawing.Point(19, 62)
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Size = New System.Drawing.Size(145, 45)
        Me.TrackBar2.TabIndex = 1
        Me.TrackBar2.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar2.Value = 10
        '
        'TrackBar3
        '
        Me.TrackBar3.Location = New System.Drawing.Point(179, 62)
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Size = New System.Drawing.Size(145, 45)
        Me.TrackBar3.TabIndex = 2
        Me.TrackBar3.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar3.Value = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckBox4)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.Caption1)
        Me.GroupBox1.Controls.Add(Me.Caption2)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.CheckBox2)
        Me.GroupBox1.Controls.Add(Me.Caption3)
        Me.GroupBox1.Controls.Add(Me.CheckBox1)
        Me.GroupBox1.Controls.Add(Me.Caption4)
        Me.GroupBox1.Controls.Add(Me.Caption5)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(669, 259)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Display"
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(271, 230)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(67, 20)
        Me.CheckBox4.TabIndex = 10
        Me.CheckBox4.Text = "Shape"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CheckBox3)
        Me.GroupBox2.Controls.Add(Me.Caption6)
        Me.GroupBox2.Controls.Add(Me.Caption7)
        Me.GroupBox2.Controls.Add(Me.TrackBar1)
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 278)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(336, 132)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Position Slider"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(174, 104)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(151, 20)
        Me.CheckBox3.TabIndex = 3
        Me.CheckBox3.Text = "Position Live Update"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Caption13)
        Me.GroupBox3.Controls.Add(Me.Caption12)
        Me.GroupBox3.Controls.Add(Me.Caption11)
        Me.GroupBox3.Controls.Add(Me.TrackBar2)
        Me.GroupBox3.Controls.Add(Me.TrackBar3)
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 417)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(336, 132)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Audio Sliders"
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(266, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 18)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "0.00"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(106, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "1.00"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Caption13
        '
        Me.Caption13.AutoSize = True
        Me.Caption13.ForeColor = System.Drawing.Color.DimGray
        Me.Caption13.Location = New System.Drawing.Point(176, 105)
        Me.Caption13.Name = "Caption13"
        Me.Caption13.Size = New System.Drawing.Size(77, 16)
        Me.Caption13.TabIndex = 5
        Me.Caption13.Text = "'TrackBar3'"
        '
        'Caption12
        '
        Me.Caption12.AutoSize = True
        Me.Caption12.ForeColor = System.Drawing.Color.DimGray
        Me.Caption12.Location = New System.Drawing.Point(16, 105)
        Me.Caption12.Name = "Caption12"
        Me.Caption12.Size = New System.Drawing.Size(77, 16)
        Me.Caption12.TabIndex = 3
        Me.Caption12.Text = "'TrackBar2'"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Caption8)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.Caption9)
        Me.GroupBox4.Controls.Add(Me.Caption10)
        Me.GroupBox4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.GroupBox4.Location = New System.Drawing.Point(355, 278)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(326, 132)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Playback Position"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Caption16)
        Me.GroupBox5.Controls.Add(Me.Caption15)
        Me.GroupBox5.Controls.Add(Me.Panel5)
        Me.GroupBox5.Controls.Add(Me.Panel4)
        Me.GroupBox5.Controls.Add(Me.Caption14)
        Me.GroupBox5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.GroupBox5.Location = New System.Drawing.Point(355, 417)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(326, 132)
        Me.GroupBox5.TabIndex = 5
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Audio Output Level"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(256, 105)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 18)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "0.00"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(108, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 18)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "0.00"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Caption16
        '
        Me.Caption16.AutoSize = True
        Me.Caption16.ForeColor = System.Drawing.Color.DimGray
        Me.Caption16.Location = New System.Drawing.Point(164, 105)
        Me.Caption16.Name = "Caption16"
        Me.Caption16.Size = New System.Drawing.Size(56, 16)
        Me.Caption16.TabIndex = 5
        Me.Caption16.Text = "'Panel5'"
        '
        'Caption15
        '
        Me.Caption15.AutoSize = True
        Me.Caption15.ForeColor = System.Drawing.Color.DimGray
        Me.Caption15.Location = New System.Drawing.Point(16, 105)
        Me.Caption15.Name = "Caption15"
        Me.Caption15.Size = New System.Drawing.Size(56, 16)
        Me.Caption15.TabIndex = 3
        Me.Caption15.Text = "'Panel4'"
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Location = New System.Drawing.Point(166, 78)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(140, 12)
        Me.Panel5.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Location = New System.Drawing.Point(19, 78)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(140, 12)
        Me.Panel4.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(11, 564)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 24)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Play"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(117, 564)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 24)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Pause"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button3.Location = New System.Drawing.Point(223, 564)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 24)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "Stop"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(582, 564)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 24)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Quit"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TaskbarBox
        '
        Me.TaskbarBox.AutoSize = True
        Me.TaskbarBox.Checked = True
        Me.TaskbarBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TaskbarBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(173, Byte), Integer), CType(CType(146, Byte), Integer))
        Me.TaskbarBox.Location = New System.Drawing.Point(345, 567)
        Me.TaskbarBox.Name = "TaskbarBox"
        Me.TaskbarBox.Size = New System.Drawing.Size(226, 20)
        Me.TaskbarBox.TabIndex = 9
        Me.TaskbarBox.Text = "Show Taskbar Progress Indicator"
        Me.TaskbarBox.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(693, 601)
        Me.Controls.Add(Me.TaskbarBox)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(189, Byte), Integer), CType(CType(159, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PVS.MediaPlayer How To... (VB.NET)"
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Caption1 As Label
    Friend WithEvents Caption2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Caption3 As Label
    Friend WithEvents Caption4 As Label
    Friend WithEvents Caption5 As Label
    Friend WithEvents Caption6 As Label
    Friend WithEvents Caption8 As Label
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents Caption7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Caption9 As Label
    Friend WithEvents Caption10 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Caption11 As Label
    Friend WithEvents Caption14 As Label
    Friend WithEvents TrackBar2 As TrackBar
    Friend WithEvents TrackBar3 As TrackBar
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Caption13 As Label
    Friend WithEvents Caption12 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Caption16 As Label
    Friend WithEvents Caption15 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents TaskbarBox As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
End Class
