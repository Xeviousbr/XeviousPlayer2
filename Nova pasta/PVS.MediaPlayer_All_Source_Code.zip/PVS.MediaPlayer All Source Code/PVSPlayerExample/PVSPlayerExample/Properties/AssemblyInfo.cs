﻿using System.Resources;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("PVSPlayerExample 0.99")]
[assembly: AssemblyDescription("PVS.MediaPlayer Sample Application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("PVS The Netherlands")]
[assembly: AssemblyProduct("PVSPlayerExample 0.99")]
[assembly: AssemblyCopyright("© 2019 PVS The Netherlands")]
[assembly: AssemblyTrademark("PVS The Netherlands")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4ffcc349-269f-4109-8375-7bfeb8fdb68c")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.9.9.40")]
[assembly: AssemblyFileVersion("0.9.9.40")]
[assembly: NeutralResourcesLanguage("en")]

