﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace MusicBox2009
{
    public partial class Form1 : Form
    {
        ArrayList aSongs = new ArrayList();
        ArrayList aScanSongs = new ArrayList();
        ArrayList aSongsFromFile = new ArrayList();
        ArrayList aSongsShuffle = new ArrayList();
        ArrayList aListState = new ArrayList();
        string strOpenedSong;
        bool stop;
        string[] tags;
        int i = 0;
        int iCurrentSong;
        bool bShuffled;

        public Form1()
        {
            InitializeComponent();

            //Setting all the tool tips
            tt1.SetToolTip(btnPlay, "Play song");
            tt1.SetToolTip(btnStop, "Stop song");
            tt1.SetToolTip(btnPause, "Pause song");
            tt1.SetToolTip(btnNext, "Next song");
            tt1.SetToolTip(btnPrev, "Previous song");
            tt1.SetToolTip(btnMuteOnOff, "Mute");
            tt1.SetToolTip(trbVolume, "Volume");
            tt1.SetToolTip(btnPlayAll, "Play All");
            tt1.SetToolTip(btnShuffle, "Shuffle Playlist");

            //setting the default volume
            trbVolume.Value = 50;
            player.settings.volume = trbVolume.Value;

            //getting the mute button image
            btnMuteOnOff.Image = Image.FromFile("kmixdocked.png");

            //displaying the treeview nodeds and childnodes
            RefreshDisplay();             
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this will open a single file and play it
            string songName;
            strOpenedSong = "";
            ofd1.Filter = "mp3 Files | *.mp3";
            ofd1.Title = "Select a text file";
            ofd1.InitialDirectory = Application.StartupPath;
            if (ofd1.ShowDialog() == DialogResult.OK)
            {
                player.URL = ofd1.FileName;
                songName = Path.GetFileNameWithoutExtension(player.URL);
                GetTagInfo(player.URL);
                player.Ctlcontrols.play();
                timer1.Enabled = true;
                this.Text = "MusicBox 2009 - " + songName;
            }            
        }   

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //exit the application
            this.Dispose();
        }

        private void getSongsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Opens a folder browser dialog box and you choose a diretory where your songs are
            //and the listview is filled with these songs
            if (fbd1.ShowDialog() == DialogResult.OK)
            {
                aSongs = new ArrayList();
                lvSongs.Items.Clear();
                string dir;
                dir = fbd1.SelectedPath;
                string[] fileEntries = Directory.GetFiles(dir);
                string files;
                string songs;
                foreach (string fileName in fileEntries)
                {
                    files = Path.GetExtension(fileName);
                    songs = Path.GetFileNameWithoutExtension(fileName);
                    if (files == ".mp3")
                    {
                        GetTagInfo(fileName);
                        aSongs.Add(fileName);
                        FillListView(fileName);
                    }
                }
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (player.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                switch (i)
                {
                    case 0:
                        slbl1.Text = "Song Title: " + tags[i];
                        break;
                    case 1:
                        slbl1.Text = "Artist: " + tags[i];
                        break;
                    case 2:
                        slbl1.Text = "Album: " + tags[i];
                        break;
                    case 3:
                        slbl1.Text = "Year: " + tags[i];
                        break;
                    default:
                        slbl1.Text = "Song Title: " + tags[0];
                        break;
                }
                i += 1;
                if (i == 5)
                {
                    i = 0;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                //if the song is playing
                if (player.playState == WMPLib.WMPPlayState.wmppsPlaying)
                {
                    int songDuration = Convert.ToInt32(player.Ctlcontrols.currentItem.duration);
                    int songPosition = Convert.ToInt32(player.Ctlcontrols.currentPosition);

                    //display the song positionin min and sec
                    //display the total time of song
                    slblPosition.Text = player.Ctlcontrols.currentPositionString;
                    slblLength.Text = player.Ctlcontrols.currentItem.durationString;
                    lblTime.Visible = true;
                    //the track bar will move with the song duration
                    trackBar1.Maximum = songDuration;
                    trackBar1.Value = songPosition;
                    //disable the open song menu item and disable or enable buttons
                    openToolStripMenuItem.Enabled = false;
                    btnStop.Enabled = true;
                    btnPlay.Visible = false;
                    btnPause.Visible = true;
                    btnPlayAll.Enabled = false;
                    btnShuffle.Enabled = false;
                    //getting the tag info for the song if available
                    GetTagInfo(player.URL);
                    string songName = Path.GetFileNameWithoutExtension(player.URL);
                    this.Text = "MusicBox 2009 - " + songName;
                }
                else
                {
                    //if song is not playing
                    slblPosition.Text = "";
                    slblLength.Text = "";
                    lblTime.Visible = false;
                    openToolStripMenuItem.Enabled = true;
                    slbl1.Text = "";
                    btnPlay.Visible = true;
                    btnStop.Enabled = false;
                    btnPause.Visible = false;
                    if (lvSongs.Items.Count > 0)
                    {
                        //btnPlayAll.Enabled = true;
                    }
                }
            }
            catch (Exception)
            {

            }
        }

        #region Functions

        public static void ShufflePlayList(ArrayList source)
        {
            try
            {
                Random rnd = new Random();
                int inx = source.Count - 1;
                while (inx > 0)
                {
                    int position = rnd.Next(inx);
                    object temp = source[inx];
                    source[inx] = source[position];
                    source[position] = temp;
                    System.Threading.Interlocked.Decrement(ref inx);
                }
            }
            catch (Exception)
            {
            }
        }

        public void RefreshDisplay()
        {
            treeView1.Nodes.Clear();
            string dir = Application.StartupPath + "\\Playlists";
            string[] fileEntries = Directory.GetFiles(dir);
            ArrayList a = new ArrayList();
            TreeNode rootNode = new TreeNode();
            treeView1.Nodes.Add("Playlists");
            treeView1.Nodes.Add("Songs");
            treeView1.Nodes[0].Nodes.Add("Create Playlist");
            treeView1.Nodes[0].Nodes[0].NodeFont = new Font("Veranda", 10, FontStyle.Italic);
            foreach (string files in fileEntries)
            {
                string strFileExt = Path.GetExtension(files);
                if (strFileExt == ".pl")
                {
                    TreeNode childNode = new TreeNode(Path.GetFileNameWithoutExtension(files));
                    treeView1.Nodes[0].Nodes.Add(childNode);
                }
            }
            treeView1.ExpandAll();
            treeView1.SelectedNode = treeView1.Nodes[1];
        }

        public void GetTagInfo(string sSong)
        {
            //Getting the tag info for the song. if the file has tag info.
            //I am working on trying to change the info within this app
            //It will display the Artist, Song Name, Album, and year in the
            //status bar at the bottom
            try
            {
                using (FileStream fs = File.OpenRead(sSong))
                {
                    if (fs.Length >= 128)
                    {
                        TagInfo tag = new TagInfo();
                        fs.Seek(-128, SeekOrigin.End);
                        fs.Read(tag.TAGID, 0, tag.TAGID.Length);
                        fs.Read(tag.Title, 0, tag.Title.Length);
                        fs.Read(tag.Artist, 0, tag.Artist.Length);
                        fs.Read(tag.Album, 0, tag.Album.Length);
                        fs.Read(tag.Year, 0, tag.Year.Length);
                        fs.Read(tag.Composer, 0, tag.Composer.Length);
                        string theTAGID = Encoding.Default.GetString(tag.TAGID);
                        if (theTAGID.Equals("TAG"))
                        {
                            string Title = Encoding.Default.GetString(tag.Title);
                            string Artist = Encoding.Default.GetString(tag.Artist);
                            string Album = Encoding.Default.GetString(tag.Album);
                            string Composer = Encoding.Default.GetString(tag.Composer);
                            string Year = Encoding.Default.GetString(tag.Year);
                            tags = new string[4] { Title, Artist, Album, Year };
                            //slbl1.Text = "Song Title: " + Title;
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void FillListView(string sSong)
        {
            try
            {
                string sFile = Path.GetFileNameWithoutExtension(sSong);

                //this takes the full file name splits the file in two by the '-' character
                //most mp3 files are like this. if yours isn't then it will display the full name 
                //of the file in one cell in the list view
                string[] a_sName = new string[2];
                int l;
                char[] splitter = { '-' };
                a_sName = sFile.Split(splitter);
                l = a_sName.Length;
                if (l == 1)
                {
                    //if no '-' is found list view will diplay the full name in the Artist cell
                    //else it will display the artist and song title in the right cell
                    //if more than one '-' is found then the first two will be displayed
                    string sArtist = a_sName[0].ToString();
                    ListViewItem listItem1 = new ListViewItem(sArtist);
                    lvSongs.Items.Add(listItem1);
                }
                else
                {
                    string sArtist = a_sName[0].ToString();
                    string sTitle = a_sName[1].ToString();
                    ListViewItem listItem1 = new ListViewItem(sTitle);
                    listItem1.SubItems.Add(new ListViewItem.ListViewSubItem(listItem1, sArtist));
                    lvSongs.Items.Add(listItem1);
                }
            }
            catch (Exception)
            {
            }
        }

        private void scanForSongs(string rootDirectory)
        {
            aSongs = new ArrayList();

            try
            {
                if (stop) return;
                foreach (string dir in Directory.GetDirectories(rootDirectory))
                {
                    if (stop) return;
                    Application.DoEvents();
                    //skips the recycled bin
                    if (dir.ToLower().IndexOf("$recycle.bin") == -1)
                        //calls the scanforsongs fucntion until no more directories are left to be scanned
                        scanForSongs(dir);
                }
                //getting the found mp3 files and displying them in the listview
                foreach (string file in Directory.GetFiles(rootDirectory))
                {
                    if (stop) return;
                    Application.DoEvents();
                    string fileExtention = Path.GetExtension(file);
                    string songNames = Path.GetFileNameWithoutExtension(file);
                    if (fileExtention == ".mp3")
                    {
                        aScanSongs.Add(file);
                        aSongs.Add(file);
                        FillListView(file);
                    }
                }

            }
            catch (Exception)
            {
            }
        }

        #endregion         

        private void btnPause_Click(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            //plays the song that is selected from the listview
            if (player.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                player.Ctlcontrols.stop();
                player.Ctlcontrols.play();
                GetTagInfo(player.URL);
            }
            else
            {
                player.Ctlcontrols.play();
                timer1.Enabled = true;
                timer2.Enabled = true;
                lblTime.Visible = true;
                if (lvSongs.Items.Count > 0)
                {
                    //btnNext.Enabled = true;
                }
            } 
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            //stops the current song that is playing
            timer1.Enabled = false;
            lblTime.Visible = false;
            timer3.Enabled = false;
            trackBar1.Value = 0;
            player.Ctlcontrols.stop();
            if (lvSongs.Items.Count > 0)
            {
                btnPlayAll.Enabled = true;
                btnShuffle.Enabled = true;
                timer3.Enabled = false;
            }
            strOpenedSong = "";
            if (lvSongs.Items.Count > 0)
            {
                //cmnu1.Enabled = true;
            } 
        }

        private void trbVolume_Scroll(object sender, EventArgs e)
        {
            player.settings.volume = trbVolume.Value;
        }

        private void btnMuteOnOff_Click(object sender, EventArgs e)
        {
            if (player.settings.mute == false)
            {
                player.settings.mute = true;
                btnMuteOnOff.Image = Image.FromFile("kmixdocked_mute.png");
            }
            else
            {
                player.settings.mute = false;
                btnMuteOnOff.Image = Image.FromFile("kmixdocked.png");
            }
        }

        private void scanForSongsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //sets the drive to be scanned the C: drive
            string sDrive = "C:\\";
            aScanSongs = new ArrayList();
            aSongs = new ArrayList();
            //clears the listview
            lvSongs.Items.Clear();
            stop = false;
            //calls the scanForSongs function
            scanForSongs(sDrive);
            aSongs = aScanSongs;
            MessageBox.Show("Done with Scan. " + aSongs.Count + " songs found.", "Done with Scan",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (lvSongs.Items.Count > 0)
            {
                btnShuffle.Enabled = true;
                btnPlayAll.Enabled = true;
            } 
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            btnPlayAll.Enabled = true;
            btnShuffle.Enabled = true;

            string sSelected = treeView1.SelectedNode.Text;
            //I have by default the "Songs" node selected when the app is loaded
            if (sSelected == "Songs")
            {
                //if (iCurrentSong != 0)
                //{
                //    //If a song is playing the song name in the list view should highlight
                //    lvSongs.Focus();
                //    lvSongs.Items[iCurrentSong].Selected = true;
                //}

                //Enabling the context menu items
                cmnu1.Items[0].Enabled = false;
                cmnu1.Items[1].Enabled = false;
                cmnu1.Items[2].Enabled = false;
                cmnu1.Items[3].Enabled = true;
                //Clearing the list view
                lvSongs.Items.Clear();
                //if the songlist has been shuffled it should keep the state after the shuffle
                //for when another node is selected and the "Song" node is selected again
                if (bShuffled)
                {
                    aSongs = new ArrayList();
                    aSongs = aListState;
                    foreach (string sSongName in aListState)
                    {
                        string sName = Path.GetFileNameWithoutExtension(sSongName);
                        FillListView(sName);
                    }
                }
                else
                {
                    aSongsFromFile = new ArrayList();
                    aSongs = new ArrayList();
                    //When the app is loaded a "Main list" is loaded from a file called songs.mpl
                    //if a "Main list" is not yet a blank list view is displayed
                    string fileName = Application.StartupPath + "\\Playlists\\" + sSelected + ".mpl";
                    if(File.Exists(fileName))
                    {
                        StreamReader strReader = new StreamReader(fileName);
                        while (!strReader.EndOfStream)
                        {
                            string name = strReader.ReadLine();
                            string song = Path.GetFileNameWithoutExtension(name);
                            FillListView(name);
                            aSongsFromFile.Add(name);
                        }
                        aSongs = aSongsFromFile;
                        aListState = aSongs;
                        strReader.Close();
                    }                    
                }
                bShuffled = false;
            }
            else
            {
                //Other noded selected other than the "Songs" node
                bShuffled = true;
                cmnu1.Items[0].Enabled = true;
                cmnu1.Items[1].Enabled = true;
                cmnu1.Items[2].Enabled = true;
                cmnu1.Items[3].Enabled = false;
                if (treeView1.SelectedNode != treeView1.Nodes[0].Nodes[0])
                {
                    lvSongs.Items.Clear();
                    if (sSelected == "Playlists")
                    {
                        return;
                    }
                    aSongsFromFile = new ArrayList();
                    aSongs = new ArrayList();
                    //After a play list is created a file(whateveryournameis.pl) is created
                    string fileName = Application.StartupPath + "\\Playlists\\" + sSelected + ".pl";
                    StreamReader strReader = new StreamReader(fileName);
                    while (!strReader.EndOfStream)
                    {
                        string name = strReader.ReadLine();
                        string song = Path.GetFileNameWithoutExtension(name);
                        FillListView(name);
                        aSongsFromFile.Add(name);
                    }
                    aSongs = aSongsFromFile;
                    strReader.Close();
                }
            }
        }

        private void createPlaylistToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string sSelected = treeView1.SelectedNode.Text;
            if (sSelected == "Create Playlist")
            {
                //the "Create Playlist" node will become editable
                treeView1.Nodes[0].Nodes[0].BeginEdit();
            }
        }

        private void treeView1_BeforeLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Node.Tag != null)
            {
                e.CancelEdit = false;
            }
        }

        private void treeView1_AfterLabelEdit(object sender, System.Windows.Forms.NodeLabelEditEventArgs e)
        {
            if (e.Label != null)
            {
                //a playlist file will be created with the name of what ever is typed in the editable label
                StreamWriter sw;
                sw = File.CreateText(Application.StartupPath + "\\Playlists\\" + e.Label.ToString() + ".pl");
                sw.Close();
            }
            //refresh the playlist
            //for some reason and I think it is a bug in VS2008 after the label is edited it will not refresh
            //this is way I got around that
            tmrRefresh.Enabled = true;
        }

        private void tmrRefresh_Tick(object sender, EventArgs e)
        {
            RefreshDisplay();
            tmrRefresh.Enabled = false;
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RefreshDisplay();
        }

        private void deletePlaylistToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //deletes the playlist selected from the treeview
            string strFilepath = Application.StartupPath + "\\Playlists\\" + treeView1.SelectedNode.Text + ".pl";
            File.Delete(strFilepath);
            RefreshDisplay();
        }

        private void treeView1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            //Gets the playlist the selected song from the listview will be added to
            if (e.Button == MouseButtons.Right)
            {
                Point pos = new Point(e.X, e.Y);
                TreeNode node = treeView1.GetNodeAt(pos);
                if (node != null)
                {
                    treeView1.SelectedNode = node;
                    cmnu1.Show(treeView1, pos);
                }
            }
            else if (e.Button == MouseButtons.Left)
            {

            }
        }

        private void treeView1_DragDrop(object sender, DragEventArgs e)
        {
            TreeNode n;

            if (e.Data.GetDataPresent("System.Windows.Forms.ListViewItem", false))
            {

                Point pt = ((TreeView)sender).PointToClient(new Point(e.X, e.Y));
                TreeNode dn = ((TreeView)sender).GetNodeAt(pt);
                ListViewItem item = (ListViewItem)e.Data.GetData("System.Windows.Forms.ListViewItem");

                n = new TreeNode(item.Text);
                n.Tag = item;

                iCurrentSong = 0;
                for (int x = 0; x < lvSongs.Items.Count; x++)
                {

                    if (lvSongs.Items[x].Selected)
                        iCurrentSong = x;
                }
                int y;
                y = iCurrentSong;
                strOpenedSong = "";
                strOpenedSong = aSongs[y].ToString();

                StreamWriter sw;
                string filepath = Application.StartupPath + "\\Playlists\\" + dn.Text + ".pl";
                sw = File.AppendText(filepath);
                sw.WriteLine(strOpenedSong);
                sw.Close();

                n.Remove();
            }
        }

        private void treeView1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void lvSongs_ItemDrag(object sender, ItemDragEventArgs e)
        {
            lvSongs.DoDragDrop(e.Item, DragDropEffects.Copy);
        }

        private void lvSongs_DoubleClick(object sender, EventArgs e)
        {
            if (player.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                iCurrentSong = 0;
                for (int x = 0; x < lvSongs.Items.Count; x++)
                {

                    if (lvSongs.Items[x].Selected)
                        iCurrentSong = x;
                }
                int y;
                y = iCurrentSong;
                btnPlay.Enabled = true;
                if (lvSongs.Items.Count > 0)
                {
                    btnNext.Enabled = true;
                    btnPrev.Enabled = true;
                    if (y == lvSongs.Items.Count - 1)
                    {
                        btnNext.Enabled = false;
                    }
                    if (y == 0)
                    {
                        btnPrev.Enabled = false;
                    }
                }
                player.Ctlcontrols.play();
                GetTagInfo(player.URL);
            }
            else
            {
                iCurrentSong = 0;
                for (int x = 0; x < lvSongs.Items.Count; x++)
                {

                    if (lvSongs.Items[x].Selected)
                        iCurrentSong = x;
                }
                int y;
                y = iCurrentSong;
                strOpenedSong = "";
                strOpenedSong = aSongs[y].ToString();
                player.URL = strOpenedSong;
                player.Ctlcontrols.stop();
                btnPlay.Enabled = true;
                if (lvSongs.Items.Count > 0)
                {
                    btnNext.Enabled = true;
                    btnPrev.Enabled = true;
                    if (y == lvSongs.Items.Count - 1)
                    {
                        btnNext.Enabled = false;
                    }
                    if (y == 0)
                    {
                        btnPrev.Enabled = false;
                    }
                }
                player.Ctlcontrols.play();
                GetTagInfo(player.URL);
            }
        }

        private void lvSongs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (player.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                iCurrentSong = 0;
                for (int x = 0; x < lvSongs.Items.Count; x++)
                {

                    if (lvSongs.Items[x].Selected)
                        iCurrentSong = x;
                }
                int y;
                y = iCurrentSong;
                btnPlay.Enabled = true;
                if (lvSongs.Items.Count > 0)
                {
                    btnNext.Enabled = true;
                    btnPrev.Enabled = true;
                    if (y == lvSongs.Items.Count - 1)
                    {
                        btnNext.Enabled = false;
                    }
                    if (y == 0)
                    {
                        btnPrev.Enabled = false;
                    }
                }
            }
            else
            {
                iCurrentSong = 0;
                for (int x = 0; x < lvSongs.Items.Count; x++)
                {

                    if (lvSongs.Items[x].Selected)
                        iCurrentSong = x;
                }
                int y;
                y = iCurrentSong;
                strOpenedSong = "";
                strOpenedSong = aSongs[y].ToString();
                player.URL = strOpenedSong;
                player.Ctlcontrols.stop();
                btnPlay.Enabled = true;
                if (lvSongs.Items.Count > 0)
                {
                    btnNext.Enabled = true;
                    btnPrev.Enabled = true;
                    if (y == lvSongs.Items.Count - 1)
                    {
                        btnNext.Enabled = false;
                    }
                    if (y == 0)
                    {
                        btnPrev.Enabled = false;
                    }
                }
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Gets the next song in the listview list and plays it
            iCurrentSong += 1;

            lvSongs.Focus();
            lvSongs.Items[iCurrentSong].Selected = true;

            player.URL = aSongs[iCurrentSong].ToString();
            strOpenedSong = aSongs[iCurrentSong].ToString();
            GetTagInfo(aSongs[iCurrentSong].ToString());
            player.Ctlcontrols.play();

            //if the first song in the play list btnPrev is disabled
            if (iCurrentSong > 0)
            {
                btnPrev.Enabled = true;
            }

            //if the last song in the list btnNext is disabled
            if (iCurrentSong != aSongs.Count - 1)
            {
                btnNext.Enabled = true;
            }
            else
            {
                btnNext.Enabled = false;
            }

            btnPlay.Enabled = false;
            btnStop.Enabled = true;
            btnPause.Enabled = true;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            iCurrentSong -= 1;

            lvSongs.Focus();
            lvSongs.Items[iCurrentSong].Selected = true;

            player.URL = aSongs[iCurrentSong].ToString();
            strOpenedSong = aSongs[iCurrentSong].ToString();
            GetTagInfo(aSongs[iCurrentSong].ToString());
            player.Ctlcontrols.play();

            if (iCurrentSong > 0)
            {
                btnPrev.Enabled = true;
            }
            else
            {
                btnPrev.Enabled = false;
            }

            if (iCurrentSong != aSongs.Count - 1)
            {
                btnNext.Enabled = true;
            }
            else
            {
                btnNext.Enabled = false;
            }

            btnPlay.Enabled = false;
            btnStop.Enabled = true;
            btnPause.Enabled = true;
        }

        private void btnPlayAll_Click(object sender, EventArgs e)
        {
            //plays all the songs in the listview
            iCurrentSong = 0;

            lvSongs.Focus();
            lvSongs.Items[iCurrentSong].Selected = true;

            if (aSongs.Count != 0)
            {
                string song = aSongs[iCurrentSong].ToString();
                strOpenedSong = song;
                player.URL = song;
                player.Ctlcontrols.play();
                btnStop.Enabled = true;
                btnPause.Enabled = true;
                btnPlay.Enabled = false;
                btnPlayAll.Enabled = false;
                GetTagInfo(song);
                timer1.Enabled = true;
                btnShuffle.Enabled = false;

                if (iCurrentSong > 0)
                {
                    btnPrev.Enabled = true;
                }

                if (iCurrentSong != aSongs.Count - 1)
                {
                    btnNext.Enabled = true;
                }
                else
                {
                    btnNext.Enabled = false;
                }
            } 
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (iCurrentSong == lvSongs.Items.Count - 1)
            {
                iCurrentSong = 0;
                btnPlayAll.Enabled = true;
                return;
            }

            timer3.Enabled = false;
            iCurrentSong += 1;
            int y;
            y = iCurrentSong;

            lvSongs.Focus();
            lvSongs.Items[iCurrentSong].Selected = true;

            strOpenedSong = "";
            strOpenedSong = aSongs[y].ToString();            
            player.URL = strOpenedSong;
            player.Ctlcontrols.play();
            btnStop.Enabled = true;
            btnPause.Enabled = true;

            GetTagInfo(strOpenedSong);

            if (iCurrentSong > 0)
            {
                btnPrev.Enabled = true;
            }

            if (iCurrentSong != aSongs.Count - 1)
            {
                btnNext.Enabled = true;
            }
            else
            {
                btnNext.Enabled = false;
            }

            if (player.playState == WMPLib.WMPPlayState.wmppsTransitioning)
            {
                btnPlay.Enabled = false;
            }
        }

        private void player_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (lvSongs.Items.Count > 0)
            {
                if ((player.playState == WMPLib.WMPPlayState.wmppsStopped) && (lvSongs.SelectedItems != null))
                {
                    timer3.Enabled = true;
                }
            }
        }

        private void btnShuffle_Click(object sender, EventArgs e)
        {
            if (bShuffled)
            {
                aSongsShuffle = new ArrayList();
                lvSongs.Items.Clear();
                ShufflePlayList(aSongs);

                int i;

                for (i = 0; i <= aSongs.Count - 1; i++)
                {
                    string fileName = aSongs[i].ToString();
                    string songName = Path.GetFileNameWithoutExtension(fileName);
                    aSongsShuffle.Add(fileName);
                    GetTagInfo(fileName);
                    FillListView(fileName);
                }

                aSongs = aSongsShuffle;
                btnPlayAll.Enabled = true;
            }
            else
            {
                aSongsShuffle = new ArrayList();
                lvSongs.Items.Clear();
                ShufflePlayList(aSongs);

                int i;

                for (i = 0; i <= aSongs.Count - 1; i++)
                {
                    string fileName = aSongs[i].ToString();
                    string songName = Path.GetFileNameWithoutExtension(fileName);
                    aSongsShuffle.Add(fileName);
                    GetTagInfo(fileName);
                    FillListView(fileName);
                }

                aSongs = aSongsShuffle;
                aListState = aSongsShuffle;
                btnPlayAll.Enabled = true;
                bShuffled = true;
            }
        }

        private void saveAsMainList_Click(object sender, EventArgs e)
        {
            string filepath;
            StreamWriter sw;
            filepath = Application.StartupPath + "\\Playlists\\Songs.mpl";
            sw = File.CreateText(filepath);
            foreach (string fileName in aSongs)
            {
                sw.WriteLine(fileName);
            }
            sw.Close();

            aSongsFromFile = new ArrayList();
            aSongs = new ArrayList();
            string sFileName = Application.StartupPath + "\\Playlists\\Songs.mpl";
            StreamReader strReader = new StreamReader(sFileName);
            while (!strReader.EndOfStream)
            {
                string name = strReader.ReadLine();
                string song = Path.GetFileNameWithoutExtension(name);
                FillListView(name);
                aSongsFromFile.Add(name);
            }
            aSongs = aSongsFromFile;
            aListState = aSongs;
            strReader.Close();
        }

        private void deleteSongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            iCurrentSong = 0;
            for (int x = 0; x < lvSongs.Items.Count; x++)
            {

                if (lvSongs.Items[x].Selected)
                    iCurrentSong = x;
            }
            aSongs.RemoveAt(iCurrentSong);
            lvSongs.Items.Clear();

            string filepath;
            StreamWriter sw;
            if (treeView1.SelectedNode.Text == "Songs")
            {
                filepath = Application.StartupPath + "\\Playlists\\" + treeView1.SelectedNode.Text + ".mpl";
                sw = File.CreateText(filepath);
                foreach (string fileName in aSongs)
                {
                    sw.WriteLine(fileName);
                    FillListView(fileName);
                }
            }
            else
            {
                filepath = Application.StartupPath + "\\Playlists\\" + treeView1.SelectedNode.Text + ".pl";
                sw = File.CreateText(filepath);
                foreach (string fileName in aSongs)
                {
                    sw.WriteLine(fileName);
                    FillListView(fileName);
                }
            }
            sw.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout fm = new frmAbout();
            fm.Show();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            player.Ctlcontrols.pause();
            player.Ctlcontrols.currentPosition = trackBar1.Value;
            player.Ctlcontrols.play();
        }
    }
}
