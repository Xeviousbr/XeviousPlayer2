Title: MusicBox2009
Description: This is my first shot at a C# application. I took a while but I think I got it. It is an mp3 player. Although it's main purpose is to be kind of media player the code shows how to scan files on a drive, fill in a treeview and list view, select items in a list view, edit nodes in a tree view, drag and drop, dialog box, timers and few things more.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6977&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
