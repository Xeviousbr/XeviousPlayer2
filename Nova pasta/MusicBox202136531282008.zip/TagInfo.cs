﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicBox2009
{
    class TagInfo
    {

        public byte[] TAGID = new byte[3];
        public byte[] Title = new byte[30];
        public byte[] Artist = new byte[30];
        public byte[] Album = new byte[30];
        public byte[] Year = new byte[4];
        public byte[] Composer = new byte[35];

    }
}
