﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web;

namespace MusicBox2009
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void btnDonate_Click(object sender, EventArgs e)
        {
            string website = "www.ambulancelifeline.com/webforms/default.aspx";
            System.Diagnostics.Process.Start("iexplore.exe", website);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
