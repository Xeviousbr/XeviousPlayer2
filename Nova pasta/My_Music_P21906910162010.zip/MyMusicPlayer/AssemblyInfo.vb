Imports System.Reflection
Imports System.Resources
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' Information about this assembly is defined by the following
' attributes.
'
' change them to the information which is associated with the assembly
' you compile.

<Assembly: AssemblyTitle("My Music Player")> 
<Assembly: AssemblyDescription("Simple MP3 music player that uses Windows MCI")> 
<assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Virtual Software")> 
<Assembly: AssemblyProduct("My Music Player")> 
<Assembly: AssemblyCopyright("Copyright � Herbert N Swearengen III 2010")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")> 

' This sets the default COM visibility of types in the assembly to invisible.
' If you need to expose a type to COM, use <ComVisible(true)> on that type.
<Assembly: ComVisible(False)> 
<Assembly: CLSCompliant(True)> 

<Assembly: NeutralResourcesLanguage("en")> 

' The assembly version has following format :
'
' Major.Minor.Build.Revision
'
' You can specify all values by your own or you can build default build and revision
' numbers with the '*' character (the default):

<Assembly: AssemblyVersion("1.5.*")> 
<Assembly: AssemblyFileVersion("1.5.0.0")> 
