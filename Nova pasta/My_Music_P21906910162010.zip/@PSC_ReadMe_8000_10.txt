Title: My Music Player (Improved!)
Description: Here is a music player that does just about everything you really need to do without being complex like Windows Media Player or iTunes. It plays MP3 files and reads ID3 tags to get artist, title, and album art. It can open and save playlists in WinAMP M3U format. And it has a shuffle feature that really works well. It can run on the desktop or in the system tray. This update adds some minor features and fixes. This update adds the ability to read wma tags and play wma (Windows Media Audio) files.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=8000&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
