This player is based on libZPlay library.
Download libzplay.dll (libzplay-2.02-sdk package) from:
http://libzplay.sourceforge.net/
